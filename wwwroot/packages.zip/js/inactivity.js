﻿$(function ($) {
	$.jq_easy_session_timeout();
});